// Code admission is a domain adapter; the generic runtime owns job lifetimes.
import { hashInput } from "../runtime/checks";
import { scopesOverlap } from "../runtime/queue";
import type { Engine, Run, X } from "../runtime/engine";
const clone = <T>(v: T): T => JSON.parse(JSON.stringify(v));
function verifiedMerge(this: Engine, r: Run, expected?: { project: string; repo: string }) {
    if (r.status !== "succeeded" || r.result !== "done") return false;
    const trusted = this.trusted(r.id); if (!trusted.ok) return false;
    const rec = trusted.entries.filter(e => e.record === "native-merge" && e.verdict === "pass").at(-1), d: any = rec?.data;
    if (!d || d.version !== 1 || !/^[0-9a-f]{40}$/.test(d.head) || !/^[A-Za-z0-9][A-Za-z0-9/_-]*$/.test(d.base) || this.queueRepo(d.repo) !== d.repo || d.project !== this.queueProject(r)) return false;
    if (expected && (d.repo !== expected.repo || d.project !== expected.project)) return false;
    const current = Bun.spawnSync(["git", "rev-parse", "--verify", `refs/heads/${d.base}`], { cwd: d.repo, stdout: "pipe", stderr: "pipe" });
    const h = current.stdout.toString().trim(); if (current.exitCode !== 0 || !/^[0-9a-f]{40}$/.test(h)) return false;
    return Bun.spawnSync(["git", "merge-base", "--is-ancestor", d.head, h], { cwd: d.repo, stdout: "pipe", stderr: "pipe" }).exitCode === 0;
  }
function scopeState(this: Engine, x: X) {
    if (x.run.ctx.nativeQueueVersion !== 1) throw new Error("historical round has no native queue binding; fresh preparation required");
    const project = this.queueProject(x.run), repo = this.queueRepo(x.ctx.repo), trusted = this.trusted(x.run.id);
    const acceptance: any = trusted.entries.filter(e => e.record === "card-answer" && (((e.data as any)?.kind === "dispatch" && (e.data as any)?.choice === "dispatch") || ((e.data as any)?.queueRecovery === true && (e.data as any)?.choice === "retry"))).at(-1)?.data;
    const deps = this.queueDependencies(x.run), specHash = hashInput(x.ctx.spec);
    if (!trusted.ok || !acceptance || acceptance.queueSpec !== specHash || acceptance.repo !== repo || acceptance.project !== project || hashInput(acceptance.dependencies) !== hashInput(deps) || !Array.isArray(acceptance.scope) || !acceptance.scope.length) throw new Error("accepted dependency/scope binding is unavailable or changed; fresh dispatch required");
    const pin = x.ctx.nativeAdmission, prior = trusted.entries.filter(e => e.record === "scope-admission").at(-1);
    if (pin && !trusted.entries.some(e => e.record === "scope-admission" && hashInput(e.data) === hashInput(pin))) throw new Error("existing scope pin has no signed binding; fresh preparation required");
    if (!pin && prior && !acceptance.queueRecovery) throw new Error("existing scope binding is missing; fresh preparation required");
    if (pin && (pin.version !== 1 || pin.repo !== repo || pin.project !== project || pin.specHash !== specHash || hashInput(pin.dependencies) !== hashInput(deps) || hashInput(pin.scope) !== hashInput(acceptance.scope))) throw new Error("native scope pin changed; fresh preparation required");
    for (const id of deps) { const parent = this.get(id); if (!parent || !this.verifiedMerge(parent, { project, repo })) return { ready: false, reason: `dependency ${id} has no verified authoritative merge` }; }
    for (const other of this.list()) {
      if (other.id === x.run.id) continue;
      const records = this.trusted(other.id), rec = records.entries.filter(e => e.record === "scope-admission").at(-1);
      const held: any = rec?.data ?? other.ctx.nativeAdmission;
      if (held?.repo !== repo || held?.project !== project) continue;
      if (!records.ok || !rec || hashInput(held) !== hashInput(other.ctx.nativeAdmission) || !Array.isArray(held.scope)) return { ready: false, reason: `scope identity unavailable for ${other.id}` };
      if (!this.verifiedMerge(other) && scopesOverlap(acceptance.scope, held.scope)) return { ready: false, reason: `scope held by ${other.id} until verified merge` };
    }
    return { ready: true };
  }

export function installCodeQueue(engine: Engine) {
  engine.queueDomain = {
    worker: (x, mode) => x.run.def.nodes.some(n => n.do === "git.merge") && ["plan", "build"].includes(mode),
    ready: x => scopeState.call(engine, x),
    merged: (r, expected) => verifiedMerge.call(engine, r, expected),
    admitted(x) {
        if (!x.ctx.nativeAdmission) {
          const data: any = engine.trusted(x.run.id).entries.filter(e => e.record === "card-answer" && (((e.data as any)?.kind === "dispatch" && (e.data as any)?.choice === "dispatch") || ((e.data as any)?.queueRecovery === true && (e.data as any)?.choice === "retry"))).at(-1)!.data;
          x.ctx.nativeAdmission = { version: 1, project: data.project, repo: data.repo, specHash: data.queueSpec, scope: clone(data.scope), dependencies: clone(data.dependencies) };
          engine.record(x, "scope-admission", { data: clone(x.ctx.nativeAdmission) });
        }
    },
    answer(r, _node, rn, c) {
      const binding = (c.kind === "dispatch" && c.answer!.choice === "dispatch") || (c.kind === "scope" && rn.data.nativeQueueCapability && c.answer!.choice === rn.data.nativeQueueCapability.retryAction);
      if (!binding || !Array.isArray(r.ctx.spec?.scope)) return {};
      return { queueRecovery: !!rn.data.nativeQueueCapability, queueSpec: hashInput(r.ctx.spec), scope: clone(r.ctx.spec.scope), project: engine.queueProject(r), repo: engine.queueRepo(r.ctx.repo), dependencies: engine.queueDependencies(r) };
    }
  };
}

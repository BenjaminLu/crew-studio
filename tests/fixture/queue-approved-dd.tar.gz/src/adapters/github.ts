// Local review remains the default. GitHub publication requires a trusted,
// exact project grant; this interface exposes no review/comment/merge endpoint.
import { existsSync, mkdirSync, mkdtempSync, readFileSync, renameSync, rmSync, writeFileSync } from "node:fs";
import { join, resolve } from "node:path";
import { tmpdir } from "node:os";
import { spawn } from "node:child_process";
import { gitArgv, gitEnv } from "../git";
import { githubHeaders, findToken } from "../github";
import { registerSecretValues, redactText } from "../secure";

export type ReviewRequest = { id: string; adapter: "local" | "github"; repo: string; base: string; branch: string; head: string; title: string; body: string; openedAt: string; url: string | null };
type OpenRequest = Omit<ReviewRequest, "id" | "adapter" | "openedAt" | "url">;
export interface PrAdapter {
  readonly id: "local" | "github";
  open(o: OpenRequest, runDir: string, signal?: AbortSignal): Promise<ReviewRequest>;
  update(pr: ReviewRequest, head: string, runDir: string, signal?: AbortSignal): Promise<ReviewRequest>;
}
const persist = (dir: string, pr: ReviewRequest) => {
  const tmp = join(dir, `pr.json.${crypto.randomUUID()}.tmp`);
  try { writeFileSync(tmp, JSON.stringify(pr, null, 1), { mode: 0o600 }); renameSync(tmp, join(dir, "pr.json")); }
  finally { rmSync(tmp, { force: true }); }
};
export class LocalPrAdapter implements PrAdapter {
  readonly id = "local" as const;
  async open(o: OpenRequest, runDir: string, signal?: AbortSignal) {
    const pr: ReviewRequest = { ...o, id: `local:${o.branch}`, adapter: "local", openedAt: new Date().toISOString(), url: null };
    signal?.throwIfAborted(); persist(runDir, pr); return pr;
  }
  async update(pr: ReviewRequest, head: string, runDir: string, signal?: AbortSignal) { const n = { ...pr, head }; signal?.throwIfAborted(); persist(runDir, n); return n; }
}

/** Trusted project-file metadata, not accepted by project-add or run parameters.
 * approvedAt/approvalId must name the captain's project/remote grant. Sensitivity
 * approval is separate and never enables GitHub writes. */
export type GitHubProjectGrant = {
  mode: "github" | "simulator"; repository: string; localPath: string;
  pushUrl: string; apiOrigin: string; base: string; branchPrefix: string;
  approvedAt: string; approvalId: string;
};
// Ambient Git variables can redirect the repository or inject config/trace
// helpers. Retain only Studio's deliberately constructed Git settings.
function publicationEnv(extra: Record<string, string> = {}) {
  const env = gitEnv(); const keep = new Set(["GIT_AUTHOR_NAME", "GIT_AUTHOR_EMAIL", "GIT_COMMITTER_NAME", "GIT_COMMITTER_EMAIL", "GIT_CONFIG_GLOBAL", "GIT_CONFIG_NOSYSTEM", "GIT_TERMINAL_PROMPT"]);
  for (const key of Object.keys(env)) if (key.startsWith("GIT_") && !keep.has(key) || key === "SSH_ASKPASS") delete env[key];
  return { ...env, ...extra };
}
function localGit(cwd: string, args: string[]) {
  const r = Bun.spawnSync(gitArgv(args), { cwd, env: publicationEnv(), stdin: "ignore", stdout: "pipe", stderr: "pipe" });
  return { ok: r.success, out: r.stdout.toString().trim() };
}
function localMust(cwd: string, args: string[]) { const r = localGit(cwd, args); if (!r.ok) throw new Error("GitHub local Git preparation failed"); return r.out; }
const slug = /^[A-Za-z0-9][A-Za-z0-9_.-]*\/[A-Za-z0-9][A-Za-z0-9_.-]*$/;
const sha = /^[a-f0-9]{40}$/;
const ref = (s: string) => typeof s === "string" && s.length < 240 && !s.startsWith("-") && localGit(process.cwd(), ["check-ref-format", "--branch", s]).ok;
export function validateGitHubGrant(g: GitHubProjectGrant) {
  if (!g || !["github", "simulator"].includes(g.mode) || !slug.test(g.repository) || !g.approvalId?.trim() || !Number.isFinite(Date.parse(g.approvedAt))) throw new Error("GitHub requires an explicit approved project remote grant");
  if (!g.localPath?.startsWith("/") || !existsSync(join(g.localPath, ".git")) || !ref(g.base) || !g.branchPrefix?.endsWith("/") || !ref(g.branchPrefix + "probe")) throw new Error("invalid GitHub project repository, base or branch prefix");
  let u: URL; try { u = new URL(g.apiOrigin); } catch { throw new Error("invalid GitHub API origin"); }
  if (u.username || u.password || u.search || u.hash || u.pathname !== "/") throw new Error("GitHub API origin must contain no credentials or path");
  if (g.mode === "github") {
    if (g.apiOrigin !== "https://api.github.com" || g.pushUrl !== `https://github.com/${g.repository}.git`) throw new Error("GitHub grant must name the exact HTTPS GitHub repository and API");
  } else if (u.protocol !== "http:" || !["127.0.0.1", "[::1]"].includes(u.hostname) || !g.pushUrl?.startsWith("/") || !existsSync(join(g.pushUrl, "HEAD")) || !existsSync(join(g.pushUrl, "objects"))) throw new Error("simulator grant requires loopback API and an existing absolute bare repository");
}

// Node's detached POSIX spawn creates a new session/process group. Keep it
// owned until cleanup; Studio exit kills only groups it actually created.
// https://nodejs.org/api/child_process.html#optionsdetached
const gitGroups = new Set<number>();
process.once("exit", () => { for (const pid of gitGroups) try { process.kill(-pid, "SIGKILL"); } catch {} });
const delay = (ms: number) => new Promise<void>(resolve => setTimeout(resolve, ms));
async function ownedGit(argv: string[], cwd: string, env: Record<string, string>, timeoutMs: number, signal?: AbortSignal) {
  signal?.throwIfAborted();
  if (process.platform === "win32") throw new Error("GitHub publication requires supported owned POSIX process groups");
  const p = spawn(argv[0], argv.slice(1), { cwd, env, detached: true, stdio: ["ignore", "pipe", "pipe"] });
  const pid = p.pid;
  if (pid) gitGroups.add(pid);
  let stdout = "", bytes = 0, exited = false;
  let end: (result: { code: number | null; failed: boolean }) => void;
  const ended = new Promise<{ code: number | null; failed: boolean }>(resolve => { end = resolve; });
  const exit = new Promise<void>(resolve => {
    p.once("exit", code => { exited = true; end({ code, failed: false }); resolve(); });
    p.once("error", () => { exited = true; end({ code: null, failed: true }); resolve(); });
  });
  p.stdout?.on("data", (chunk: Buffer) => { bytes += chunk.length; if (bytes > 1_000_000) end({ code: null, failed: true }); else stdout += chunk.toString("utf8"); });
  p.stdout?.on("error", () => end({ code: null, failed: true }));
  p.stderr?.on("error", () => end({ code: null, failed: true }));
  p.stderr?.on("data", () => {}); // drain without retaining private Git error output
  const onAbort = () => end({ code: null, failed: true }); signal?.addEventListener("abort", onAbort, { once: true }); if (signal?.aborted) onAbort();
  const timer = setTimeout(() => end({ code: null, failed: true }), timeoutMs);
  const groupSignal = (sig: NodeJS.Signals) => { if (pid) try { process.kill(-pid, sig); } catch (e: any) { if (e.code !== "ESRCH") throw new Error("GitHub owned process cleanup failed"); } };
  const alive = () => { if (!pid) return false; try { process.kill(-pid, 0); return true; } catch (e: any) { return e.code !== "ESRCH"; } };
  const result = await ended; clearTimeout(timer); signal?.removeEventListener("abort", onAbort);
  try {
    if (result.failed) { groupSignal("SIGTERM"); await delay(25); }
    groupSignal("SIGKILL");
    // Pipes are not a lifetime signal: helpers inherit them. Bound the buffered
    // drain after killing the owned group, then close our endpoints explicitly.
    await delay(10); p.stdout?.destroy(); p.stderr?.destroy();
    if (!exited) await Promise.race([exit, delay(200)]);
    const deadline = Date.now() + 300;
    while (alive() && Date.now() < deadline) await delay(5);
    if (!exited || alive()) { const error = new Error("GitHub owned process cleanup incomplete; temporary client retained"); (error as any).retainClient = true; throw error; }
    if (pid) gitGroups.delete(pid);
    if (result.failed || result.code !== 0) throw new Error("GitHub push or lease check failed (remote changed, authentication or timeout)");
    return stdout.trim();
  } catch (e: any) { if (alive()) e.retainClient = true; throw e; }
}

async function boundedBytes(response: Response, cap: number) {
  const reader = response.body?.getReader(); if (!reader) return new Uint8Array();
  const chunks: Uint8Array[] = []; let count = 0;
  try { for (;;) { const { done, value } = await reader.read(); if (done) break; count += value.byteLength; if (count > cap) throw new Error("GitHub response exceeds limit"); chunks.push(value); } }
  finally { await reader.cancel().catch(() => {}); }
  const bytes = new Uint8Array(count); let offset = 0; for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; } return bytes;
}
async function boundedResponse(response: Response, cap: number) { return new TextDecoder().decode(await boundedBytes(response, cap)); }

export class GitHubPrAdapter implements PrAdapter {
  readonly id = "github" as const;
  private tokenValue: string | null = null;
  private active = new Set<string>();
  readonly grant: GitHubProjectGrant;
  get publicationOwners() { return this.active.size; }
  constructor(grant: GitHubProjectGrant, readonly token: () => string | null, readonly timeoutMs = 15_000) {
    validateGitHubGrant(grant);
    if (!Number.isFinite(timeoutMs) || timeoutMs < 50 || timeoutMs > 60_000) throw new Error("invalid GitHub request timeout");
    this.grant = Object.freeze({ ...grant });
    registerSecretValues(() => [this.tokenValue]);
  }
  private credential() {
    const t = this.token()?.trim(); if (!t || /[\r\n]/.test(t)) throw new Error("GitHub authentication is required");
    this.tokenValue = t; return t;
  }
  /** The complete allowlist; arbitrary URLs and generic request methods are not exposed. */
  private async api(method: "GET" | "POST" | "PATCH", suffix: string, body?: Record<string, any>, signal?: AbortSignal) {
    signal?.throwIfAborted();
    const allowed = ["GET", "POST", "PATCH"].includes(method) && (method === "GET" ? /^\/(?:pulls\?[a-zA-Z0-9%=&_.+-]+|pulls\/[1-9][0-9]*)$/ : method === "POST" ? suffix === "/pulls" : /^\/pulls\/[1-9][0-9]*$/.test(suffix));
    if (!allowed) throw new Error("GitHub endpoint is not allowlisted");
    if (method !== "GET") {
      const fields = method === "POST" ? ["title", "body", "head", "base"] : ["title", "body", "base"];
      if (!body || Object.keys(body).length !== fields.length || !fields.every(k => typeof body[k] === "string") || Object.keys(body).some(k => !fields.includes(k))) throw new Error("GitHub request body is not allowlisted");
    } else if (body !== undefined) throw new Error("GitHub GET does not accept a body");
    const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const r = await fetch(`${this.grant.apiOrigin}/repos/${this.grant.repository}${suffix}`, { method, headers: { ...githubHeaders(this.credential()), ...(body ? { "content-type": "application/json" } : {}) }, body: body ? JSON.stringify(body) : undefined, signal: signal ? AbortSignal.any([signal, controller.signal]) : controller.signal, redirect: "error" });
      // Never return vendor error text, which can echo credentials or private data.
      if (!r.ok) throw new Error(`GitHub ${r.status}${r.status === 403 || r.status === 429 ? " (authorization or rate limit; retry after resolving)" : ""}`);
      const text = await boundedResponse(r, 1_000_000);
      return JSON.parse(text);
    } catch (e: any) { throw new Error(e?.message?.startsWith("GitHub ") ? e.message : "GitHub request failed or timed out"); }
    finally { clearTimeout(timer); }
  }
  recordedIdentity(pr: any) {
    return !!pr && pr.adapter === "github" && pr.repo === this.grant.localPath && pr.base === this.grant.base && typeof pr.branch === "string" && ref(pr.branch) && pr.branch.startsWith(this.grant.branchPrefix) && typeof pr.id === "string" && /^[1-9][0-9]*$/.test(pr.id) && Number.isSafeInteger(Number(pr.id)) && sha.test(pr.head) && pr.url === `https://github.com/${this.grant.repository}/pull/${pr.id}`;
  }
  /** Typed, grant-bound read surface. No arbitrary endpoint or URL is accepted. */
  async remoteRead(kind: "pull" | "ref" | "policy" | "checks" | "statuses", target: string, page = 1, signal?: AbortSignal): Promise<any> {
    signal?.throwIfAborted();
    if (!Number.isInteger(page) || page < 1 || page > 50) throw new Error("GitHub pagination limit");
    let suffix: string;
    if (kind === "pull" && /^[1-9][0-9]*$/.test(target) && page === 1) suffix = `/pulls/${target}`;
    else if (kind === "ref" && ref(target) && target.startsWith(this.grant.branchPrefix) && page === 1) suffix = `/git/ref/heads/${encodeURIComponent(target)}`;
    else if (kind === "policy" && target === this.grant.base && page === 1) suffix = `/branches/${encodeURIComponent(target)}/protection/required_status_checks`;
    else if ((kind === "checks" || kind === "statuses") && sha.test(target)) suffix = `/commits/${target}/${kind === "checks" ? "check-runs?filter=all&" : "status?"}per_page=100&page=${page}`;
    else throw new Error("GitHub read target is not allowlisted");
    return this.readResponse(suffix, signal);
  }
  private async readResponse(suffix: string, signal?: AbortSignal) {
    const controller = new AbortController(), timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const response = await fetch(`${this.grant.apiOrigin}/repos/${this.grant.repository}${suffix}`, { headers: githubHeaders(this.credential()), redirect: "error", signal: signal ? AbortSignal.any([signal, controller.signal]) : controller.signal });
      if (!response.ok) throw new Error(`GitHub ${response.status}`);
      return JSON.parse(await boundedResponse(response, 1_000_000));
    } catch (e: any) { throw new Error(/^GitHub \d+$/.test(e?.message) ? e.message : "GitHub read failed or timed out"); }
    finally { clearTimeout(timer); }
  }
  async jobLog(id: number, start: number, end: number, signal?: AbortSignal): Promise<{ classification: string; text?: string; start?: number; end?: number; total?: number }> {
    signal?.throwIfAborted();
    if (!Number.isSafeInteger(id) || id < 1 || !Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || end < start || end - start >= 65_536) throw new Error("invalid GitHub log range");
    const controller = new AbortController(), timer = setTimeout(() => controller.abort(), this.timeoutMs), combined = signal ? AbortSignal.any([signal, controller.signal]) : controller.signal;
    try {
      const response = await fetch(`${this.grant.apiOrigin}/repos/${this.grant.repository}/actions/jobs/${id}/logs`, { headers: githubHeaders(this.credential()), redirect: "manual", signal: combined });
      if (response.status !== 302) { await response.body?.cancel(); return { classification: response.status === 416 ? "range-unsatisfiable" : "unsupported-log-download" }; }
      const location = response.headers.get("location"); await response.body?.cancel(); let url: URL;
      try { url = new URL(location ?? ""); } catch { throw new Error("GitHub log redirect refused"); }
      // GitHub log downloads use its owned blob service. Simulator only permits
      // its exact granted loopback origin, never a general test URL bypass.
      const allowed = this.grant.mode === "simulator" ? url.origin === this.grant.apiOrigin : url.protocol === "https:" && /^(?:[a-z0-9-]+\.)+(?:blob\.core\.windows\.net|githubusercontent\.com)$/.test(url.hostname);
      if (!allowed || url.username || url.password || url.hash) throw new Error("GitHub log redirect refused");
      const download = await fetch(url, { headers: { range: `bytes=${start}-${end}` }, redirect: "manual", signal: combined });
      if (download.status === 416) { await download.body?.cancel(); return { classification: "range-unsatisfiable" }; }
      if (download.status !== 206) { await download.body?.cancel(); return { classification: "unsupported-range" }; }
      const m = /^bytes ([0-9]+)-([0-9]+)\/([0-9]+)$/.exec(download.headers.get("content-range") ?? "");
      if (!m || Number(m[1]) !== start || Number(m[2]) > end || Number(m[2]) < start || Number(m[3]) <= Number(m[2])) throw new Error("GitHub log Content-Range refused");
      const bytes = await boundedBytes(download, end - start + 1);
      if (bytes.length !== Number(m[2]) - start + 1) throw new Error("GitHub log byte length refused");
      return { classification: "range", text: redactText(new TextDecoder().decode(bytes), [this.tokenValue]).replace(/https:\/\/[^\s<>"']+\?[^\s<>"']+/g, "[download URL redacted]"), start, end: Number(m[2]), total: Number(m[3]) };
    } catch (e: any) { throw new Error(e?.message?.startsWith("GitHub log") ? e.message : "GitHub log read failed or timed out"); }
    finally { clearTimeout(timer); }
  }
  private valid(o: OpenRequest) {
    validateGitHubGrant(this.grant);
    if (resolve(o.repo) !== resolve(this.grant.localPath) || o.base !== this.grant.base || !sha.test(o.head) || !ref(o.branch)) throw new Error("review request does not match the approved project target");
    if (!o.branch.startsWith(this.grant.branchPrefix)) throw new Error("naming approval required for a branch outside the approved prefix");
    if (typeof o.title !== "string" || !o.title.trim() || o.title.length > 256 || typeof o.body !== "string" || o.body.length > 60_000) throw new Error("invalid pull request title or body");
    if (!localGit(o.repo, ["cat-file", "-e", `${o.head}^{commit}`]).ok) throw new Error("review head is not a local commit");
  }
  private response(p: any, o: OpenRequest, expectedId?: string, content = false) {
    if (!Number.isSafeInteger(p?.number) || p.number < 1 || p.state !== "open" || p.head?.ref !== o.branch || p.head?.sha !== o.head || p.head?.repo?.full_name !== this.grant.repository || p.base?.ref !== o.base || p.base?.repo?.full_name !== this.grant.repository || (expectedId && String(p.number) !== expectedId)) throw new Error("GitHub returned a mismatched pull request target or head");
    if (p.html_url !== `https://github.com/${this.grant.repository}/pull/${p.number}` || typeof p.title !== "string" || typeof p.body !== "string") throw new Error("GitHub returned an invalid pull request record");
    if (content && (p.title !== o.title || p.body !== o.body)) throw new Error("GitHub returned mismatched PR publication content");
    return p;
  }
  /** A temporary bare client contains only the requested object database, no
   * project config, remotes, hooks, credential helpers, URL rewrites or project proxy settings.
   * GitHub credentials exist only in the subprocess environment. */
  private async push(o: OpenRequest, expected: string | null, signal?: AbortSignal) {
    const dir = mkdtempSync(join(tmpdir(), "studio-gh-push-")); let retainClient = false;
    try {
      localMust(dir, ["init", "--bare", "-q", "."]);
      const objects = localMust(o.repo, ["rev-parse", "--path-format=absolute", "--git-path", "objects"]);
      if (/[\r\n]/.test(objects)) throw new Error("invalid repository object path");
      mkdirSync(join(dir, "objects", "info"), { recursive: true }); writeFileSync(join(dir, "objects", "info", "alternates"), objects + "\n");
      const token = this.credential();
      const extras = this.grant.mode === "github" ? { GIT_CONFIG_COUNT: "2", GIT_CONFIG_KEY_0: "http.https://github.com/.extraHeader", GIT_CONFIG_VALUE_0: `Authorization: Basic ${Buffer.from(`x-access-token:${token}`).toString("base64")}`, GIT_CONFIG_KEY_1: "credential.helper", GIT_CONFIG_VALUE_1: "" } : {};
      const command = (args: string[]) => ownedGit(gitArgv(["-c", "protocol.file.allow=" + (this.grant.mode === "simulator" ? "always" : "never"), ...args]), dir, publicationEnv(extras), this.timeoutMs, signal);
      const remote = await command(["ls-remote", "--refs", "--", this.grant.pushUrl, `refs/heads/${o.branch}`]);
      const lines = remote ? remote.split("\n") : []; if (lines.length > 1 || (lines.length && !new RegExp(`^[a-f0-9]{40}\\s+refs/heads/${o.branch.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`).test(lines[0]))) throw new Error("invalid remote branch response");
      const current = lines.length ? lines[0].slice(0, 40) : null;
      if (current === o.head) return; // interrupted publication/update: recover without a second push
      if (current !== expected) throw new Error("GitHub push refused: remote branch lease mismatch");
      await command(["push", "--porcelain", `--force-with-lease=refs/heads/${o.branch}:${expected ?? ""}`, "--", this.grant.pushUrl, `${o.head}:refs/heads/${o.branch}`]);
    } catch (e: any) { retainClient = !!e.retainClient; throw e; }
    finally { if (!retainClient) rmSync(dir, { recursive: true, force: true }); }
  }
  private async locked<T>(branch: string, f: () => Promise<T>) { if (this.active.has(branch)) throw new Error("GitHub publication already in progress for this branch"); this.active.add(branch); try { return await f(); } finally { this.active.delete(branch); } }
  async open(o: OpenRequest, runDir: string, signal?: AbortSignal): Promise<ReviewRequest> {
    signal?.throwIfAborted(); this.valid(o);
    return this.locked(o.branch, async () => {
      const q = new URLSearchParams({ state: "open", head: `${this.grant.repository.split("/")[0]}:${o.branch}`, base: o.base, per_page: "100" });
      const list = await this.api("GET", `/pulls?${q}`, undefined, signal);
      if (!Array.isArray(list) || list.length > 1) throw new Error("GitHub pull request lookup is ambiguous");
      // Existing matching PR is the durable recovery anchor. A moved/foreign
      // head is never force overwritten by a new run without its recorded lease.
      if (list.length) this.response(list[0], o);
      await this.push(o, null, signal);
      const p = list.length ? this.response(await this.api("PATCH", `/pulls/${list[0].number}`, { title: o.title, body: o.body, base: o.base }, signal), o, String(list[0].number), true) : this.response(await this.api("POST", "/pulls", { title: o.title, body: o.body, head: o.branch, base: o.base }, signal), o, undefined, true);
      const pr: ReviewRequest = { ...o, adapter: "github", id: String(p.number), url: p.html_url, openedAt: p.created_at ?? new Date().toISOString() };
      signal?.throwIfAborted(); persist(runDir, pr); return pr;
    });
  }
  async update(pr: ReviewRequest, head: string, runDir: string, signal?: AbortSignal): Promise<ReviewRequest> {
    signal?.throwIfAborted(); const o = { ...pr, head }; this.valid(o);
    if (pr.adapter !== "github" || !/^[1-9][0-9]*$/.test(pr.id) || !sha.test(pr.head) || pr.url !== `https://github.com/${this.grant.repository}/pull/${pr.id}`) throw new Error("invalid recorded GitHub PR identity");
    return this.locked(pr.branch, async () => {
      const before = await this.api("GET", `/pulls/${pr.id}`, undefined, signal);
      // A retry may observe the new head after a successful push and failed PATCH.
      this.response(before, { ...pr, head: before?.head?.sha === head ? head : pr.head }, pr.id);
      await this.push(o, pr.head, signal);
      const p = this.response(await this.api("PATCH", `/pulls/${pr.id}`, { title: pr.title, body: pr.body, base: pr.base }, signal), o, pr.id, true);
      const n = { ...pr, head, url: p.html_url }; signal?.throwIfAborted(); persist(runDir, n); return n;
    });
  }
}

export function projectPrAdapter(project: { path: string | null; github?: GitHubProjectGrant } | null, dataDir: string): PrAdapter {
  if (!project?.github) return new LocalPrAdapter();
  if (!project.path || resolve(project.path) !== resolve(project.github.localPath)) throw new Error("GitHub grant does not match registered project path");
  return new GitHubPrAdapter(project.github, () => findToken(dataDir).token);
}
